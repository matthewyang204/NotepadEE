
ex self
ex companion
